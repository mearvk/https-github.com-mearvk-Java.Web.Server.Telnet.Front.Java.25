Joy Mech Fight Translation Patch
Version joy.mech
AlanMidas(king_midas_@hotmail.com or alan@apexmail.com)

Stuff done:
Toma - Big Font In battles
AlanMidas - other stuff 


Special thanks:
Toma for the fonty stuff, and a bit of beta testing.

Not much else here seeing as I never really officially announced this translation.