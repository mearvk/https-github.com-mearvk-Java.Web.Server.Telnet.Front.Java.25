			Fire Bird README.TXT



Fire Bird v1.01
Copyright (c) 1999 - 2000 Dragoon-X Translations
Released 2.15.00
Check http://www.emucamp.com/dxtrans for the latest on this patch, and other
projects by Dragoon-X Translations
Please send bug reports to dxtrans@hotmail.com

I. Patch Information
	A. Introduction
		1.) Kueller's Comments
	B. Game History
		1.) What the hell is Fire Bird, anyways?
		2.) Prior Translation Attempts
		3.) Patch History
	C. Thank You's
	D. Copyright Information

A. Introduction

	1.) Kueller's Comments

Hello, yet again, and welcome to Dragoon-X Translation's second major release, Fire Bird!
Honestly, I never thought that I would ever make it to a first release, much less a second. Needless to
say, I'm very excited. And although it took us a year to translate 2 somewhat small NES games, this second year
is going to be bigger and better than the first, I guarantee it. Well, enough blabbering, enjoy the game!


B. Game History

	1.) What the hell is Fire Bird, anyways?

This game was originally spawned off of a low budget, Japanese anime by the name of Fighbird (or Faibird). It involved
a team of pilots who pilot Fire Birds, which are ships which can morph into different things, such as tanks, and planes (elite!).
They always battled against an evil Emperor, with plans to take over the world. There is also
a very cool Fire Bird game for the Gameboy. If anyone has any more information about this
anime, or would be able to get us a copy of it, drop me a line at kueller@black-hole.com

	2.) Prior Translation Attempts

The first attempt to translated Fire Bird came from a group called PL Trans Force. They were a group of
Polish hackers, who were attempting to translate FB into english. They were doing quite well, and even released
a patch, but unfortunately, internal matters tore the group apart, and the translation went belly up. The second attempt was
a secret project, much like this was, by a group named Imperial Translations. I guess they were still working on it, but since
the project was secret, I had no idea the game was already taken. However, since we were much further in the game, and their 
translation was not progressing, they halted the project. The Harper from Imperial Translations provided us with an awesome
title screen hack for Fire Bird, much thanks to him!


	3.) Patch History

V1.01
- Inserted transformation translation.
- Correct all text issues.
- Decided to leave mid level kanji as is, just cause it looks cool, and my graphic hacking skills suck.

V1.00
- Initial release.

C. Thank You's

Dragoon-X Translations would like to thank the following for helping make
this translation possible!

PL Trans Force - Showing me the eliteness of Fire Bird.
Xeur - For allowing us to dump the script in your lap to translate on such short notice. :P
The Harper - Encouragement, and for the awesome title screen hack.
Spinner 8 - Helping out with title screen stuff.
Confederated Translation Company - For providing the Advanced ROM Hacking Board.
Zoop & EmuCamp - Thanks for the webspace!


D. Copyright Information

	Fire Bird is copyright (c) 1991 to Irem Co. Dragoon-X Translations is in no way affiliated
with Irem, and hence, this patch should _NOT_ be distributed with the ROM, either in a zip, or "pre patched".
This translation is copyright (c) 1999 - 2000 by Dragoon-X Translations, and is intended for private use. I swear to God, someone
will die if I find this on eBay, or in Electronics Botique. All rights reserved.


