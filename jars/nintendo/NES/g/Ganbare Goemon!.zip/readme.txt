                    Ganbare Goemon 1 README.TXT


Ganbare Goemon 1 v1.00
Copyright(c) 1998-2000 Dragoon-X Translations
Public Release: 5.22.00
Check http://www.emucamp.com/dxtrans for the latest on this patch, and other
projects by Dragoon-X Translations
Please send bug reports to dxtrans@hotmail.com

I. Patch Information
	A. Introduction
		1.) Kueller's Comments
	B. Game History
		1.) The Illustrious Goemon
		2.) Prior Translation Attempts
		3.) Patch History
	C. Ganbare Goemon Translation Staff
	D. Thank You's
	E. Copyright Information

A.) Introduction

	1.) Kueller's Comments

This release marks Dragoon-X's first translation release of the new year, hopefully
one of many to come in remainder of the year. This translation was sort of an unexpected
project, given to me by Spinner 8 right before his quitting the scene. I questioned his
motive for wanting to work on Ganbare Goemon, because as you all know, another patch
exists for this very game, by none other than Neo Demiforce. He explained that there were several
reasons as to why he chose this particular game. As you may or may not know, Ganbare Goemon 1
is a Konami game, which usually means a weird mapper and low compatibility with current
NES emulators. Along with their localization patch, Neo Demiforce also included another hack
which allowed the game to be somewhat playable in NESticle. From what Spinner has told me,
this hack only works up to a point in NESticle, and once that point is reached, graphics become
distorted and the game crashes. Another reason this game was re-translated was because of
the Neo Demiforce patch was, as far as I have been told, incomplete. My role in this translation
was not a big one, but Spinner wanted me to finish it and release it under DX, and so I did.

B.) Game History
	1.) The Illustrious Goemon

The "Goemon" series in Japan is quite popular, with games spanning over every
major Nintendo console. Despite it's popularity in Japan, no attempt was made to bring
Goemon to America. However, recent interest in the Goemon series has led to a strong movement
to translate these interesting games.

	2.) Prior Translation Attempts

The only other translation attempt that I am aware of for this game is the Neo
Demiforce translation. The current patch covers approximately 70% of the game's 
text, however, I am assuming the game freezes and crashes earlier than that in NESticle.

	3.) Patch History
V1.00b
- Public beta release.
V0.99b
- Private beta release.


C.) Ganbare Goemon Translation Staff

Production:
	Kueller
	Spinner 8

Translation:
	Xeur

Lead ROM Hacking:
	Kueller
	Spinner 8

Beta Tester:
	Neil_

D.) Thank You's
Dragoon-X Translations would like to thank the following people:

Neil_ - Thanks for beta testing on such short notice!
Confederated Translation Company - For having the spot translations done.
EmuCamp & Zoop - Providing Dragoon-X with webspace. Thanks!
#romhack - Always good for a laugh.
Spirit in the Contraption - Anxiously awaiting the relaunch...


E.) Copyright Information
Ganbare Goemon 1 is copyright (c) 1986 to Konami. Dragoon-X Translations is in no way affiliated
with Konami, and hence, this patch should _NOT_ be distributed with the ROM, either in a zip, or "prepatched".
This translation is copyright (c) 1998 - 2000 by Dragoon-X Translations, and is intended for private use. I swear to God, someone
will die if I find this on eBay, or in Electronics Botique. All rights reserved.

