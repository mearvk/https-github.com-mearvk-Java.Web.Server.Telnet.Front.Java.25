Doki! Doki! Yuuenchi (Doki! Doki! Amusement Park!) English Translation 
v1.1
(31 October 2000) 
No Talent Translations

--------------------
Members
--------------------
- Klarth (kefka_5000@hotmail.com)

--------------------
What's new?
--------------------
- I seemed to have forgotten something that made the title
screen look empty, and thus crappy.  Now I've added a horrible
rendition of that something to the title screen, making it
still crappy but a little nicer to look at.

--------------------
I.   The Game
II.  Project History
III. Completed
IV.  Incomplete
V.   Thanks
VI.  Tools Used
VII. Legal Crap
--------------------

--------------------
I. The Game
--------------------
- You're a child that wears a helmet and walks around killing
things with balls and stuff.  And you get to ride a roller
coaster type thing.  Um, yeah.. it's fun, anyway.. go play it!

--------------------
II. Project History
--------------------
- I was searching for a new project after I finished the Mini
Putt page, and I saw "Doki! Doki! Yuuenchi" as the game's 
title.  That made me think of Doki! Doki! Panic, and being
that it was 4 in the morning and I'd been studying calculus 
for 3 hours, I thought that perhaps Yuuenchi meant Panic, or
something.  So I played the game, quickly realized that it was
not Doki Doki Panic (which is an FDS game, btw), but was 
hooked on the game by then.  Once again, I saw no japanese 
text, nor did I find any text when I went through the rom with
Tile Layer.  Anyway, I decided to "translate" the title screen
again.  I was rolling right along, and had an awesome font 
kicking for the word "amusement" that looked like a roller 
coaster, and was just about ready to make the IPS.  And then I
stupidly closed Tile Layer and erased the editted game when I 
meant to copy it to a different folder.  So then I got pissed, 
went and took my Calculus final, came back here and made a 
really poor imitation of my original efforts.  So that's why 
it looks like crap.. maybe I'll try and fix it again another 
day when I'm not as tired and not so bored with that 
particular game.  Well, at least to my credit, the tile-layout
in this game was much more confusing and difficult to edit 
than the Mini Putt tiles were.

- I decided to leave the title as Doki! Doki! Amusement park, 
because it sounds and looks cooler than Thump! Thump! 
Amusement Park!

--------------------
III. Completed
--------------------
- To the best of my knowledge, everything.

--------------------
IV. Incomplete
--------------------
- Nothing, hopefully.  May make the title screen prettier 
sometime, though.

--------------------
V. Thanks
--------------------
- Ballz, for reminding me what "Doki! Doki!" meant.

- Gideon Zhi and the others from The Whirlpool's message
board, for tolerating my stupid questions and helping me out.

- The Whirlpool (http://donut.parodius.com), RPGd 
(http://rpgd.emulationworld.com), and all the other cool
translation/emulation sites I regularly visit.

- final exams for summer school, for giving me the drive to 
do something creative other than studying.

- my computer, for not completely dying yet.

- all other people out there who helped or encouraged me, or 
who are just cool people.

--------------------
VI. Tools Used
--------------------
- Tile Layer v0.50b by Snow Bro

- JNES v0.30a by Jabo 
 (http://jnes.vintagegaming.com)

- Snes-Tool 1.2 by the M.C.A and Elite

--------------------
VII. Legal Crap
--------------------
- You may not redistribute this patch without this readme file 
included.  You may not sell this patch for profit of any kind. 
Doki! Doki! Yuuenchi is property of Vap, copyright 1991.  Blah blah.  
Thump! Thump! Amusement Park!