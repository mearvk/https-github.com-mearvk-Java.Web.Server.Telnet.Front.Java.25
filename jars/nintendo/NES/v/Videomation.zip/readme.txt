Hi,

I am currently borrowing a US NES Videomation cartridge (by T�HQ, NES-V8-USA).
Thanks to Sean Walters for lending it to me.

Videomation is a paint/art program, similar in concept to Mario Paint on the
SNES. It uses a board previously unknown to me, the CPROM board.

Since this is a licensed game, it probably deserves a low mapper number. I am
provisionally using mapper 13 to denote the CPROM mapper.


Per my extended .nes header proposal, the following bits are set in the header:
  Header byte 10 bit 4:
   Bit set   = This cartridge does not have extra WRAM at $6000-$7FFF
  Header byte 10 bit 5:
   Bit set   = The mapper hardware used does have bus conflicts



CPROM Board Details
-------------------
Videomation uses a NES-CPROM-02 PCB. It has 256kbit (32Kbyte) PRG ROM, and *16K
CHR RAM* using *two* 6264 RAM chips.

Mapping is provided by a 74HC04, 74HC08, and 74HC161. Scrolling is hard-wired
to horizontal in this board; PA10 is connected to VRAM A10, which is "vertical
mirroring".



Mapper operation
----------------
This should be quite simple to support in emulators. The recommendations I give
here partly extend the CPROM functionality.

Mirroring is hard-wired to horizontal or vertical; use the setting in the .nes
header.

Mapping is set by writing to $8000-$FFFF. The CPROM board has bus conflicts, so
the game will write to addresses which contain the value it is writing.

CHR page size is 4K.

The lowest 4K of CHR RAM always appears at PPU $0000-$0FFF. Which page appears
at PPU $1000-$1FFF can be set by writing to $8000-$FFFF. The value written
looks like this:

        D7 D6 D5 D4 D3 D2 D1 D0
        -----------------------
         -  -  p  p  -  -  c  c

D5 & D4 select which 32K PRG page appears at $8000-$FFFF.
D1 & D0 select which 4K CHR RAM page appears at PPU $1000-$1FFF.

Note:
The CPROM board only supports up to 32K PRG ROM. However, the states of D5 & D4
are latched, so similarly to the GNROM mapper (66), it will be best to
implement support for switching PRG pages.

Paging does not change when the Reset button is pressed. Paging state may be
random at power-on time.


-- Mark
