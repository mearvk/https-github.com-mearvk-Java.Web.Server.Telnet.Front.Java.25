Transformers - Mystery of Comvoy
v1.00 
(7 November 2000)
No Talent Translations - http://www.geocities.com/rokarumbaba/translation/

NOTICE!!  This translation only works well in certain emulators.. 
I don't know why, as I'm not an emulator author. I do know that 
it works in the latest versions of JNES, Famtasia, and NESticle 
(as of the time of this writing).

--------------------
Members
--------------------
- Klarth (kefka_5000@hotmail.com)

--------------------
I.   The Game
II.  Project History
III. Completed
IV.  Incomplete
V.   Thanks
VI.  Tools Used
VII. Legal Crap
--------------------

--------------------
I. The Game
--------------------
- You are Optimus Prime, fighting against the evil Decepticons 
to .. uh .. do something.  Unfortunately for the fate of the
universe, you die.  Continuosly. There is no mercy for you, no 
hit points.. only death.  And when you finally do get past the 
first side scrolling part, you'll ask yourself "what the hell 
am I supposed to do to this ball thing that keeps shooting out 
little flying things."  But you shall never know, because the 
programmers never added anything else into the game.  You
simply die again, know that it's "more than meets the eye," 
and listen to that catchy little "Game Over" tune.  Kind of
reminds me of Ninja Gaiden in that respect, except you could
FREAKING WIN NINJA GAIDEN!!!!!  *cough*  And then you die.

--------------------
II. Project History
--------------------
- I was discussing my other crappy "translations" that I'd
done, when TheRedEye mentioned a crappy title hack translation
for Transformers - Convoy no Nazo.  So after searching around
for it, I found it on Zophar's Domain (the only site with 
permission to host it).. it was done by a group called "The
Elite Hacking Force" (who have since temporarily quit so that
they can improve on their hacking skills).  ZD lists the title
of the translation as "Transformers: Mystery of Ultra Magnus 
(a.k.a. Transformers: The Mystery of Fire Convoy)" .. it only
took me a moment to decide that the game was impossible enough,
had little enough to translate (read: title screen), and was
actually pretty cool to play. (Did I mention that you die?) So
I decided that the game qualified to be a No Talent translation
project, and I sat down and "translated" the title screen.
People, please realize that the name of the game is 
Transformers - Comvoy no Nazo (which translates to Transformers 
- Mystery of Comvoy), not Convoy no Nazo .. where the Elite 
Hacking Force got Mystery of Fire Convoy from, I do not know.

- THINGS TO NOTE!!!!  

1) This translation only works well in certain
emulators.. I don't know why, as I'm not an emulator author. I 
do know that it works in the latest versions of JNES, Famtasia, 
and NESticle (as of the time of this writing).

2) I may remove the "No Talent Translations Proudly Presents"
at a later time, or change it to read "Transformers - Comvoy no 
Nazo" or something.  For now, I think it doesn't look too bad.

--------------------
III. Completed
--------------------
- To the best of my knowledge, everything.

--------------------
IV. Incomplete
--------------------
- Nothing, hopefully.  May make the title screen prettier 
sometime, though.

--------------------
V. Thanks
--------------------
- TheRedEye, for making me decide to take on this project.

- The Elite Hacking Force, for making me think that this needed
to be done.

- The Whirlpool (http://donut.parodius.com), RPGd 
(http://rpgd.emulationworld.com), and all the other cool
translation/emulation sites I regularly visit.

--------------------
VI. Tools Used
--------------------
- Tile Layer v0.50b by Snow Bro

- JNES v0.30a by Jabo 
 (http://jnes.vintagegaming.com)

- Snes-Tool 1.2 by the M.C.A and Elite

--------------------
VII. Legal Crap
--------------------
- You may not redistribute this patch without this readme file 
included.  You may not sell this patch for profit of any kind. 
Transformers - Comvoy no Nazo is property of Takara, copyright 1986.  Blah blah.  
More than meets the eye! (and you die now)